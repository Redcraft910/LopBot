package fr.redcraft.bot.command.defaut;

import java.awt.Color;

import fr.redcraft.bot.BotDiscord;
import fr.redcraft.bot.command.Command;
import fr.redcraft.bot.command.CommandMap;
import fr.redcraft.bot.command.Command.ExecutorType;
import net.dv8tion.jda.core.EmbedBuilder;
import net.dv8tion.jda.core.JDA;
import net.dv8tion.jda.core.Permission;
import net.dv8tion.jda.core.entities.Game.GameType;
import net.dv8tion.jda.core.entities.Guild;
import net.dv8tion.jda.core.entities.Game;
import net.dv8tion.jda.core.entities.Message;
import net.dv8tion.jda.core.entities.MessageChannel;
import net.dv8tion.jda.core.entities.TextChannel;
import net.dv8tion.jda.core.entities.User;

public class CommandDefault {
	
	private final BotDiscord botDiscord;
	private final CommandMap commandMap;
	
	public CommandDefault(BotDiscord botDiscord, CommandMap commandMap){
		this.botDiscord = botDiscord;
		this.commandMap = commandMap;
	}
	
	@Command(name="end",type=ExecutorType.CONSOLE)
	private void stop(){
		
		botDiscord.setRunning(false);
	}
	
	@Command(name="ip",type=ExecutorType.USER)
	private void ip(User user, MessageChannel channel){
		
		if(channel instanceof TextChannel){
			TextChannel textChannel = (TextChannel)channel;	
			if(!textChannel.getGuild().getSelfMember().hasPermission(Permission.MESSAGE_EMBED_LINKS)) return;
		}
		EmbedBuilder builder = new EmbedBuilder();
		builder.setAuthor(user.getName(), null, user.getAvatarUrl()+"?size=256");
		builder.setTitle("Ip");
		builder.setImage("https://www.casimages.com/i/180813101948870020.png.html");

		builder.setDescription("[>](1) le message a été envoyé depuis le channel "+channel.getName());
		builder.setDescription("L'ip du serveur est : Play.Life-Of-Parks.ovh 1.9 --> 1.13 (Les cracks sont autorisée)");
		builder.setColor(Color.green);
		
		channel.sendMessage(builder.build()).queue();

		channel.sendMessage("L'ip du serveur est : Play.Life-Of-Parks.ovh (Les cracks sont activés)");
	}

	@Command(name="info",type=ExecutorType.USER)
	private void info(User user, MessageChannel channel){
		if(channel instanceof TextChannel){
			TextChannel textChannel = (TextChannel)channel;
			if(!textChannel.getGuild().getSelfMember().hasPermission(Permission.MESSAGE_EMBED_LINKS)) return;
		}
		
		EmbedBuilder builder = new EmbedBuilder();
		builder.setAuthor(user.getName(), null, user.getAvatarUrl()+"?size=256");
		builder.setTitle("Informations");
		
		builder.setColor(Color.green);
		
		channel.sendMessage(builder.build()).queue();
	}
	
	@Command(name="status",type=ExecutorType.USER)
	private void status(User user, MessageChannel channel){
		if(channel instanceof TextChannel){
			TextChannel textChannel = (TextChannel)channel;
			if(!textChannel.getGuild().getSelfMember().hasPermission(Permission.MESSAGE_EMBED_LINKS)) return;
		}
		EmbedBuilder builder = new EmbedBuilder();
		builder.setTitle("Status");
		builder.setDescription("-<Life-Of-Parks>- :white_check_mark: \n\nFreeFreStyleParc :white_check_mark: \n\n  MinParcDisneyLand :white_check_mark: \n\n  Nigloland :white_check_mark: \n\n  ParcAsterix :white_check_mark: \n");
		builder.setColor(Color.green);
		
		channel.sendMessage(builder.build()).queue();
	}
	@Command(name = "clean", type = ExecutorType.ALL, description = "Affiche le level d'un joueur")
    private void clean(MessageChannel channel, User user, String args[], Message message, Guild guild) {
        
    if (guild.getMember(user).hasPermission(Permission.ADMINISTRATOR)) {
    
        int message2;
        try {
            message2 = Integer.parseInt(args[0]);
        }catch(NumberFormatException e) {
            message2 = 0;
            channel.sendMessage("Vous devez écrire un chiffre valide").queue();
            return;
        }
        
            channel.getIterableHistory().takeAsync(message2)
                   .thenAccept(channel::purgeMessages);
            
            channel.sendMessage("J'ai supprimé "+message2+" messages.").queue();
        
    }
	}
	
    @Command(name="recrutement",type=ExecutorType.USER)
	private void Recrutement(User user, MessageChannel channel){
		if(channel instanceof TextChannel){
			TextChannel textChannel = (TextChannel)channel;
			if(!textChannel.getGuild().getSelfMember().hasPermission(Permission.MESSAGE_EMBED_LINKS)) return;
		}
		EmbedBuilder builder = new EmbedBuilder();
		builder.setTitle("Status");
		builder.setDescription("-<Life-Of-Parks>- :white_check_mark: \n\nFreeFreStyleParc :white_check_mark: \n\n  MinParcDisneyLand :white_check_mark: \n\n  Nigloland :white_check_mark: \n\n  ParcAsterix :white_check_mark: \n");
		builder.setColor(Color.green);
		
		channel.sendMessage(builder.build()).queue();
	}

}


