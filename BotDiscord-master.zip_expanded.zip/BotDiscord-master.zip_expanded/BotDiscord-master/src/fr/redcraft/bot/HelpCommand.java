package fr.redcraft.bot;

import net.dv8tion.jda.core.EmbedBuilder;
import net.dv8tion.jda.core.entities.Guild;
import net.dv8tion.jda.core.entities.MessageChannel;
import net.dv8tion.jda.core.entities.User;
import net.dv8tion.jda.core.entities.impl.UserImpl;
import java.awt.Color;

import fr.redcraft.bot.command.Command;
import fr.redcraft.bot.command.CommandMap;
import fr.redcraft.bot.command.Command.ExecutorType;


public class HelpCommand {

	private final CommandMap commandMap;

	public HelpCommand(CommandMap commandMap) {
		this.commandMap = commandMap;
	}
	@Command(name="help",type=ExecutorType.USER,description="affiche la liste des commandes")
	private void help(User user, MessageChannel channel, Guild guild) {

		EmbedBuilder builder = new EmbedBuilder();
		builder.setTitle("__***Liste des commandes : ***__");
		builder.setColor(Color.ORANGE);
		builder.setAuthor(user.getName());
		builder.setThumbnail("https://imgur.com/HqDVhPg");
		builder.setFooter(guild.getName(), guild.getIconUrl());

		builder.addField("***Musique***", "*-play [URL]* --> Permet de demarrer une musique\n"

+ "*-skip* --> Permet de passer a la piste suivante\n"
+ "*-stop* --> Permet de stoper la musique en cours de lecture \n"
+ "*-play* --> Permet de lancer une musique\n"

+ "*-pause* --> Permet de mettre en pause la piste. Pour redemarrer la musique faites -pause", false);
		builder.addField("***Utils***", "*-info* --> Affiche les informations sur le bot Discord\n"
				+ "*-ip* --> Affiche l'addresse ip du serveur !\n"

				+ "*-status* --> Affiche le status du serveur ainsi que des parcs\n",false);




		if(!user.hasPrivateChannel()) user.openPrivateChannel().complete();
		((UserImpl)user).getPrivateChannel().sendMessage(builder.build()).queue();

		System.out.println("La commande help a �t� utilis� par : "+user.getName());
	}

	@Command(name="hh",type=ExecutorType.USER,description="affiche la liste des commandes")
	private void hh(User user, MessageChannel channel, Guild guild) {

		EmbedBuilder builder = new EmbedBuilder();
		builder.setTitle("__***Liste des commandes : ***__");
		builder.setColor(Color.ORANGE);
		builder.setAuthor(user.getName());
		builder.setThumbnail("");
		builder.setFooter(guild.getName(), guild.getIconUrl());

		builder.addField("***Musique***", "*-play [URL]* --> Permet de demarrer une musique\n"
				+ "*-skip* --> Permet de passer a la piste suivante\n"
				+ "*-stop* --> Permet de stoper la musique en cours de lecture \n"
				+ "*-play* --> Permet de lancer une musique\n"

				+ "*-pause* --> Permet de mettre en pause la piste. Pour redemarrer la musique faites =pause", false);



		builder.setDescription("__***De nombreuses commandes a venir***__");


		channel.sendMessage(builder.build()).queue();
		System.out.println("La commande help a �t� utilis� par : "+user.getName());
	}
}